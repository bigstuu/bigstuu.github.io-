import { moduleDefinition } from '../../moduleapi'

const plugin: moduleDefinition = {
    display_name: 'ading2210 for Edupuzzle Answers',
    description: 'thanks',
    id: 'cred',
    section: 'credit',
    disabled: true,
    custom_render: false,
}

export default plugin
